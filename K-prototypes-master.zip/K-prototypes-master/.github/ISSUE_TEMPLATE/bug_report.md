---
name: Bug report
about: Create a report to help improve `kmodes`
title: ''
labels: bug
assignees: ''

---

## Expected Behavior


## Actual Behavior


## Steps to Reproduce the Problem

  1.
  1.
  1.

## Specifications

  - Version:
  - Platform:
